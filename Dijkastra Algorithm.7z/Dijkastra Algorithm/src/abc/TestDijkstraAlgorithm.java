package abc;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class TestDijkstraAlgorithm {

    private List<Vertex> nodes;
    private List<Edge> edges;

    @Test
    public void testExcute() {
        nodes = new ArrayList<Vertex>();
        edges = new ArrayList<Edge>();
        for (int i = 0; i < 9; i++) {
            Vertex location = new Vertex("Node_" + i, "Node_" + i);
            nodes.add(location);
        }
                
        
        addLane("Edge_0", 0, 1, 11048);
        addLane("Edge_1", 0, 2, 8383);
        addLane("Edge_2", 0, 3, 3181);
        addLane("Edge_3", 0, 4, 7256);
        addLane("Edge_4", 0, 5, 8603);
        addLane("Edge_5", 0, 6, 8296);
        addLane("Edge_6", 0, 7, 3326);
        addLane("Edge_7", 0, 8, 13783);
        addLane("Edge_8", 1, 2, 5383);
        addLane("Edge_9", 1, 3, 8334);
        addLane("Edge_10", 1, 4, 3110);
        addLane("Edge_11", 1, 5, 5505);
        addLane("Edge_12", 1, 6, 5584);
        addLane("Edge_13", 1, 7, 8240);
        addLane("Edge_14", 1, 8, 5716);
        addLane("Edge_15", 2, 3, 5672);
        addLane("Edge_16", 2, 4, 5348);
        addLane("Edge_17", 2, 5, 3308);
        addLane("Edge_18", 2, 6, 2949);
        addLane("Edge_19", 2, 7, 5653);
        addLane("Edge_20", 2, 8, 8443);
        addLane("Edge_21", 3,4 , 8465);
        addLane("Edge_22", 3, 5, 8282);
        addLane("Edge_23", 3, 6, 5766);
        addLane("Edge_24", 3, 7, 3196);
        addLane("Edge_25", 3, 8, 13840);
        addLane("Edge_26", 4, 5, 3848);
        addLane("Edge_27", 4, 6, 5325);
        addLane("Edge_28", 4, 7, 8265);
        addLane("Edge_29", 4, 8, 5582);
        addLane("Edge_30", 5, 6, 2918);
        addLane("Edge_31", 5, 7, 8115);
        addLane("Edge_32", 5, 8, 5761);
        addLane("Edge_33", 6, 7, 5891);
        addLane("Edge_34", 6, 8, 8461);
        addLane("Edge_35", 7, 8, 11234);
 
        
        // Lets check from location Loc_1 to Loc_10
        Graph graph = new Graph(nodes, edges);
        DijkstraAlgorithm dijkstra = new DijkstraAlgorithm(graph);
        dijkstra.execute(nodes.get(0));
        LinkedList<Vertex> path = dijkstra.getPath(nodes.get(8));

        assertNotNull(path);
        assertTrue(path.size() > 0);

        for (Vertex vertex : path) {
            System.out.println(vertex);
        }
    }
    
    private void addLane(String laneId, int sourceLocNo, int destLocNo,
            int duration) {
        Edge lane = new Edge(laneId,nodes.get(sourceLocNo), nodes.get(destLocNo), duration );
        edges.add(lane);
    }
}
